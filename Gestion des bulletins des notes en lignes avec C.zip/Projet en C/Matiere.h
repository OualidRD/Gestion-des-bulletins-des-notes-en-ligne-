#ifndef MATIERE_H
#define MATIERE_H

void ajouterMtiere();
void supprimerMatiere();
void gestionMatier();
void gestionMatier1();
void afficherMatieres();

struct Matiere
{int Num ;
int references;
char libelle[100];
int coefficient;
};

int rechMat(int numrech);

#endif //MATIERE_H
