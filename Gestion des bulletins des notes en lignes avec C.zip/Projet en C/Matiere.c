#include<stdio.h>


struct Matiere
{
int references;
char libelle[100];
int coefficient;
int numero;
};
//----fonction de rechereche----//
int rechMat(int numrech)
{
    struct Matiere Mat;
    FILE *F;
    F = fopen("Matiere.txt", "a+");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 0;
    }

    while (fscanf(F, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
    {
        if (Mat.references == numrech)
        {
            fclose(F);
            return 1; // Reference found
        }
    }

    fclose(F);
    return 0; // Reference not found
}

//-------------Fonction d'ajout-------------//
void ajouterMatiere()
{
    struct Matiere Mat;
    FILE *F;
    int num;
    F = fopen("Matiere.txt", "a+");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    printf("\n Entrer le reference de la matiere : ");
    scanf("%d", &num);
    fflush(stdin);

    while (rechMat(num) == 1)
    {
        printf("\n La matiere existe deja :");
        printf("\n Entrez un autre reference :");
        scanf("%d", &num);
    }

    Mat.references = num;

    printf("\n Entrer le libele :");
    scanf(" %99[^\n]", Mat.libelle);
    fflush(stdin);

    printf("\n Entrer le coefficient :");
    scanf("%d", &Mat.coefficient);
    fflush(stdin);

    fprintf(F, "%d,%s,%d\n", Mat.references, Mat.libelle, Mat.coefficient);
    fclose(F);

    printf("Ajout de la matiere effectue avec succes.\n");
}


//----------Suppression Matiere-----------//
void supprimerMatiere()
{
    char rep;
    struct Matiere Mat;
    int NumRech;
    printf("Entrer le reference de la matiere a supprimer : ");
    scanf("%d", &NumRech);
    fflush(stdin);

    if (rechMat(NumRech) == 1)
    {
        printf("\nVoulez-vous vraiment supprimer la matiere ? (O/N): ");
        scanf(" %c", &rep);
        fflush(stdin);

        if (rep == 'o' || rep == 'O')
        {
            FILE *F, *Fich;
            F = fopen("Matiere.txt", "r");
            Fich = fopen("TempMatiere.txt", "w");

            if (F == NULL || Fich == NULL)
            {
                printf("Erreur lors de l'ouverture des fichiers.\n");
                return;
            }

            while (fscanf(F, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
            {
                if (NumRech != Mat.references)
                {
                    fprintf(Fich, "%d,%s,%d\n", Mat.references, Mat.libelle, Mat.coefficient);
                }
            }

            fclose(Fich);
            fclose(F);
            remove("Matiere.txt");
            rename("TempMatiere.txt", "Matiere.txt");
            printf("Suppression effectuee avec succes.\n");
        }
        else
        {
            printf("\nSuppression annulee.\n");
        }
    }
    else
    {
        printf("\nLa matiere n'existe pas. Suppression annulee.\n");
    }
}


//-----------Afficher matiere--------------------//
void afficherMatieres()
{
    FILE *F;
    struct Matiere Mat;

    F = fopen("Matiere.txt", "r");

    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    printf("\n Liste des matieres :\n");
    printf("--------------------------------------------------\n");
    printf(" Reference \t Libelle \t Coefficient\n");
    printf("--------------------------------------------------\n");

    while (fscanf(F, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
    {
        printf(" %d \t\t %s \t\t %d\n", Mat.references, Mat.libelle, Mat.coefficient);
    }

    printf("--------------------------------------------------\n");

    fclose(F);
}
//-------gestion matiere1--------
void gestionMatier()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    AJOUTER MATIERE \n");
    printf("\t\t\t\t\t\t [2]:    SUPPRIMER MATIERE \n");
    printf("\t\t\t\t\t\t [3]:    AFFICHER MATIERE \n");
    printf("\t\t\t\t\t\t [4]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");

}
//-----------gestion Matiere1---------
void gestionMatier1()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    Math \n");
    printf("\t\t\t\t\t\t [2]:    Fan�ais \n");
    printf("\t\t\t\t\t\t [3]:    langage C \n");
    printf("\t\t\t\t\t\t [4]:    Base donnee \n");
    printf("\t\t\t\t\t\t [5]:    Traitement signal \n");
    printf("\t\t\t\t\t\t [6]:    java \n");
    printf("\t\t\t\t\t\t [7]:    dev web \n");
    printf("\t\t\t\t\t\t [8]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");
}
