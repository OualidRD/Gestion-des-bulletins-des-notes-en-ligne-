#include <stdio.h>
#include"Etudiant.h"
#include"Matiere.h"
#include"Classe.h"
#include"Note.h"
struct Bulletin
{   int id_Bulletin ;
    int numeroEtudiant;
    int codeClasseBulettin;;
    int referenceMatiere;
    int noteBulletin;
};

//-------gestion Bulletin--------

void gestionBulletin()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    Generer Bulletin \n");
    printf("\t\t\t\t\t\t [2]:    Afficher Bulletin \n");
    printf("\t\t\t\t\t\t [3]:    Generer un bulletin individuel\n");
    printf("\t\t\t\t\t\t [4]:    Supprimer Bulletin \n");
    printf("\t\t\t\t\t\t [5]:    Calculer moyenne des notes des matieres d'un etudiant \n");
    printf("\t\t\t\t\t\t [6]:    Calculer moyenne des etudiants d'une classe \n");
    printf("\t\t\t\t\t\t [7]:    Les etudiant qui on valider(note entre en parametre) \n");
    printf("\t\t\t\t\t\t [8]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");

}





//---------Fonction qui g�n�re des Bulletins-------------//
void genererBulletins() {
    FILE *Fetudiant, *Fmatiere, *Fnote, *FBulletin;
    struct Etudiant Etud;
    struct Matiere Mat;
    struct Note Note;
    struct Bulletin Bulletin;

    Fetudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "r");
    FBulletin = fopen("Bulletin.txt", "w");

    if (Fetudiant == NULL || Fmatiere == NULL || Fnote == NULL || FBulletin == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    while (fscanf(Fetudiant, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6) {
        fseek(Fmatiere, 0, SEEK_SET);

        while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3) {
            fseek(Fnote, 0, SEEK_SET);

            while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &Note.numero, Note.matiere, Note.niveau, &Note.note) == 4) {
                if (Note.numero == Etud.Num && strcmp(Note.matiere, Mat.libelle) == 0) {
                    // Enregistrement dans le fichier Bulletin.txt
                    // Enregistrement dans le fichier Bulletin.txt
                    Bulletin.id_Bulletin++;
                    Bulletin.numeroEtudiant = Note.numero;
                    Bulletin.codeClasseBulettin = Etud.CodeClasse;
                    Bulletin.referenceMatiere = Mat.references;
                    Bulletin.noteBulletin = Note.note;
                    fprintf(FBulletin, "%d;%d;%d;%d;%d\n",Bulletin.id_Bulletin ,Bulletin.numeroEtudiant, Bulletin.codeClasseBulettin, Bulletin.referenceMatiere,Bulletin.noteBulletin);
                }
            }
        }
    }

    fclose(Fetudiant);
    fclose(Fmatiere);
    fclose(Fnote);
    fclose(FBulletin);

    printf("Bulletins generes avec succes.\n");
}

//-----------Affichage Bulletins-----------------------//
void afficherBulletins() {
    FILE *FBulletin;
    struct Bulletin Bulletin;

    FBulletin = fopen("Bulletin.txt", "r");

    if (FBulletin == NULL) {
        printf("Erreur lors de l'ouverture du fichier Bulletin.txt.\n");
        return;
    }

    printf("\n--------- Affichage du Bulletin ---------\n");
    printf("Num Etudiant | Code Classe | Ref Matiere | Note\n");

     while (fscanf(FBulletin, "%d;%d;%d;%d;%d\n",&Bulletin.id_Bulletin ,&Bulletin.numeroEtudiant, &Bulletin.codeClasseBulettin, &Bulletin.referenceMatiere,&Bulletin.noteBulletin) == 5) {
        printf("%12d | %11d | %11d | %4d\n", Bulletin.numeroEtudiant, Bulletin.codeClasseBulettin, Bulletin.referenceMatiere, Bulletin.noteBulletin);
          printf("---------------------------------------------------------------\n");
    }

    printf("-----------------------------------------\n");

    fclose(FBulletin);
}

//---------------------Fonction Bullentin individuel-------------------------//

void GenererBulletinIndividuel(int numeroEtudiant) {
    FILE *Fetudiant, *Fmatiere, *Fnote, *FBulletin;
    struct Etudiant Etud;
    struct Matiere Mat;
    struct Note Note;
    struct Bulletin Bulletin;

    Fetudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "r");
    FBulletin = fopen("Bulletin.txt", "a"); // Utilisation du mode "a" pour ajouter au fichier existant

    if (Fetudiant == NULL || Fmatiere == NULL || Fnote == NULL || FBulletin == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    // Recherche de l'�tudiant par son num�ro
    int etudiantTrouve = 0;
    while (fscanf(Fetudiant, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6) {
        if (Etud.Num == numeroEtudiant) {
            etudiantTrouve = 1;
            break;
        }
    }

    if (!etudiantTrouve) {
        printf("�tudiant non trouv�.\n");
        fclose(Fetudiant);
        fclose(Fmatiere);
        fclose(Fnote);
        fclose(FBulletin);
        return;
    }

    // Affichage des informations de l'�tudiant
    printf("------- Informations sur l'�tudiant -------\n");
    printf("Num�ro : %d\n", Etud.Num);
    printf("Nom : %s\n", Etud.Nom);
    printf("Pr�nom : %s\n", Etud.Prenom);
    printf("Email : %s\n", Etud.email);
    printf("Date de naissance : %s\n", Etud.datenaiss);
    printf("Code de la classe : %d\n", Etud.CodeClasse);
    printf("------------------------------------------\n");

    fseek(Fmatiere, 0, SEEK_SET);

    while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3) {
        fseek(Fnote, 0, SEEK_SET);

        while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &Note.numero, Note.matiere, Note.niveau, &Note.note) == 4) {
            if (Note.numero == Etud.Num && strcmp(Note.matiere, Mat.libelle) == 0) {
                // Enregistrement dans le fichier Bulletin.txt
                Bulletin.id_Bulletin++;
                    Bulletin.numeroEtudiant = Note.numero;
                    Bulletin.codeClasseBulettin = Etud.CodeClasse;
                    Bulletin.referenceMatiere = Mat.references;
                    Bulletin.noteBulletin = Note.note;
                    fprintf(FBulletin, "%d;%d;%d;%d;%d\n",Bulletin.id_Bulletin ,Bulletin.numeroEtudiant, Bulletin.codeClasseBulettin, Bulletin.referenceMatiere,Bulletin.noteBulletin);
                printf("---------------------------------------------------------------\n");
            }
        }
    }

    printf("Bulletin g�n�r� avec succ�s pour l'�tudiant num�ro %d.\n", numeroEtudiant);

    fclose(Fetudiant);
    fclose(Fmatiere);
    fclose(Fnote);
    fclose(FBulletin);
}

//------------------Fonction supprimer Bulletin----------------------//
void supprimerBulletin(int numeroEtudiant) {
    FILE *FBulletin, *FTemp;
    struct Bulletin Bulletin;

    FBulletin = fopen("Bulletin.txt", "r");
    FTemp = fopen("TempBulletin.txt", "w");

    if (FBulletin == NULL || FTemp == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    int bulletinTrouve = 0;

    while (fscanf(FBulletin, "%d;%d;%d;%d;%d\n",&Bulletin.id_Bulletin ,&Bulletin.numeroEtudiant, &Bulletin.codeClasseBulettin, &Bulletin.referenceMatiere,&Bulletin.noteBulletin) == 5) {
        if (Bulletin.numeroEtudiant == numeroEtudiant) {
            bulletinTrouve = 1;

        } else {
            fprintf(FTemp, "%d;%d;%d;%d;%d\n", Bulletin.id_Bulletin,Bulletin.numeroEtudiant, Bulletin.codeClasseBulettin, Bulletin.referenceMatiere, Bulletin.noteBulletin);
        }
    }

    fclose(FBulletin);
    fclose(FTemp);


    remove("Bulletin.txt");
    rename("TempBulletin.txt", "Bulletin.txt");

    if (bulletinTrouve) {
        printf("Suppression du bulletin pour l'�tudiant num�ro %d effectu�e avec succ�s.\n", numeroEtudiant);
    } else {
        printf("Bulletin non trouv� pour l'�tudiant num�ro %d.\n", numeroEtudiant);
    }
}


//--------------------------Fonction pour calculer la moyenne des matieres d'un etudiant-------------------//
float calculerMoyenneEtudiant(int numeroEtudiant) {
    FILE *Fmatiere, *Fnote, *FBulletin;
    struct Matiere Mat;
    struct Note Note;
    struct Bulletin Bulletin;

    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "r");
    FBulletin = fopen("Bulletin.txt", "r");

    if (Fmatiere == NULL || Fnote == NULL || FBulletin == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return -1; // Valeur de retour pour indiquer une erreur
    }

    int totalCoefficients = 0;
    float sommeNotes = 0.0;

    // Lire les notes et les coefficients de chaque mati�re de l'�tudiant
    while (fscanf(FBulletin, "%d;%d;%d;%d;%d\n",&Bulletin.id_Bulletin ,&Bulletin.numeroEtudiant, &Bulletin.codeClasseBulettin, &Bulletin.referenceMatiere,&Bulletin.noteBulletin) == 5) {
        if (Bulletin.numeroEtudiant == numeroEtudiant) {
            fseek(Fmatiere, 0, SEEK_SET);
            while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3) {
                if (Mat.references == Bulletin.referenceMatiere) {
                    totalCoefficients += Mat.coefficient;
                    sommeNotes += (float)(Bulletin.noteBulletin * Mat.coefficient);
                    break; // Sortir de la boucle d�s qu'on trouve la mati�re
                }
            }
        }
    }

    fclose(Fmatiere);
    fclose(Fnote);
    fclose(FBulletin);

    if (totalCoefficients > 0) {
        // Calculer la moyenne en divisant la somme des notes par le total des coefficients
        float moyenne = sommeNotes / totalCoefficients;
        return moyenne;
    } else {
        return -1; // Retourner -1 si aucune mati�re n'a �t� trouv�e pour l'�tudiant
    }
}

//----------------Fonction pour calculer la moyenne des �tudiants d'une classe------------------------/
void calculerMoyenneClasse(int codeClasse) {
    FILE *Fmatiere, *Fnote, *FBulletin, *FEtudiant;
    FEtudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "r");
    FBulletin = fopen("Bulletin.txt", "r");
	
    if (FEtudiant == NULL || Fmatiere == NULL || Fnote == NULL || FBulletin == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    printf("\n------- Moyennes des �tudiants de la classe %d -------\n", codeClasse);

    int nombreEtudiants = 0;
    float sommeMoyennes = 0.0;

    struct Bulletin bulletin;

    while (fscanf(FBulletin, "%d;%d;%d;%d;%d\n", &bulletin.id_Bulletin, &bulletin.numeroEtudiant, &bulletin.codeClasseBulettin, &bulletin.referenceMatiere, &bulletin.noteBulletin) == 5) {
        if (bulletin.codeClasseBulettin == codeClasse) {
            float totalNotes = 0.0;
            int totalCoefficients = 0;

            fseek(Fmatiere, 0, SEEK_SET);
			struct Etudiant etudiant;
            struct Matiere matiere;
while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &matiere.references, matiere.libelle, &matiere.coefficient) == 3) {
    fseek(Fnote, 0, SEEK_SET);

    struct Note note;
    while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &note.numero, note.matiere, note.niveau, &note.note) == 4) {
        if (note.numero == bulletin.numeroEtudiant && strcmp(note.matiere, matiere.libelle) == 0) {
            totalNotes += (float)(note.note * matiere.coefficient);
            totalCoefficients += matiere.coefficient;
            break;
        }
    }
}


            if (totalCoefficients > 0) {
                float moyenneEtudiant = totalNotes / totalCoefficients;
                //printf("�tudiant %d : %.2f\n", bulletin.numeroEtudiant, moyenneEtudiant);
                sommeMoyennes += moyenneEtudiant;
                nombreEtudiants++;
            }
        }
    }

    fclose(FEtudiant);
    fclose(Fmatiere);
    fclose(Fnote);
    fclose(FBulletin);

    if (nombreEtudiants > 0) {
        float moyenneClasse = sommeMoyennes / nombreEtudiants;
        printf("\nMoyenne de la classe %d : %.2f\n", codeClasse, moyenneClasse);
    } else {
        printf("\nAucun �tudiant trouv� dans la classe %d.\n", codeClasse);
    }
}

//-------------Fonction affihcer les bulletin Valid�------------------//
void afficherBulletinsValides(int noteSeuil) {
    FILE *FBulletin;
    struct Bulletin Bulletin;

    FBulletin = fopen("Bulletin.txt", "r");

    if (FBulletin == NULL) {
        printf("Erreur lors de l'ouverture du fichier Bulletin.txt.\n");
        return;
    }

    printf("\n--------- Affichage des Bulletins Valid�s ---------\n");
    printf("Num Etudiant | Code Classe | Ref Matiere | Note\n");

    while (fscanf(FBulletin, "%d;%d;%d;%d;%d\n", &Bulletin.id_Bulletin, &Bulletin.numeroEtudiant, &Bulletin.codeClasseBulettin, &Bulletin.referenceMatiere, &Bulletin.noteBulletin) == 5) {
        if (Bulletin.noteBulletin >= noteSeuil) {
            printf("%12d | %11d | %11d | %4d\n", Bulletin.numeroEtudiant, Bulletin.codeClasseBulettin, Bulletin.referenceMatiere, Bulletin.noteBulletin);
            printf("---------------------------------------------------------------\n");
        }
    }

    printf("-----------------------------------------\n");

    fclose(FBulletin);
}

