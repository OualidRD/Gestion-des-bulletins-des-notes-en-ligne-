#ifndef CLASSE_H
#define CLASSE_H

enum niveau {DEUST,licence,master,cycle};
void ajouterClasse();
void supprimerClasse();
void gestionClasses();
void gestionClasses1();
void afficherClasse();

int rechClasse(int codeRech);
struct classe
{
    int code ;
    char nom[100];
    enum niveau niveau;
};

#endif //CLASSE_H
