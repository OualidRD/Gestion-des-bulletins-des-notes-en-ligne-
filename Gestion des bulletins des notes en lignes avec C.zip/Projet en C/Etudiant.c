#include<stdio.h>
#include<stdlib.h>
#include "Classe.h"
struct Etudiant
{
	int Num ;
	char Nom[100];
	char Prenom[100];
	char email[100];
	char datenaiss[100];
	int CodeClasse;
};


struct Etudiant Etud ;
//----fonction de rechereche----//
int rech(int numrech)
{
    struct Etudiant Etud;
    FILE *F;
    F = fopen("Etudiant.txt", "r");

    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return -1;
    }

    while (fscanf(F, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6)
    {
        if (Etud.Num == numrech)
        {
            fclose(F);
            return 1;
        }
    }

    fclose(F);
    return -1;
}
//----fonction d'ajout----//
void ajouterEtudiant()
{
    struct Etudiant Etud;
    struct classe Classe;
    FILE *F, *FClasse;
    int num,i;
	FClasse = fopen("Classe.txt", "r");
    F = fopen("Etudiant.txt", "a+");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    printf("\n Entrer le numero du nouveau etudiant : ");
    scanf("%d", &num);
    fflush(stdin);
    while (rech(num) == 1)
    {
    	
        printf("\n Ce numero existe deja : ");
        printf("\n Entrer le numero Etudiant : ");
        scanf("%d", &num);
        fflush(stdin);
    }

    Etud.Num = num;

    printf("\n Entrer le nom : ");
    scanf("%99s", Etud.Nom);
    fflush(stdin);

    printf("Entrer le prenom : ");
    scanf("%99s", Etud.Prenom);
    fflush(stdin);

    printf("Entrer l'email : ");
    scanf("%99s", Etud.email);
    fflush(stdin);

    printf("Entrer la date de naissance : ");
    scanf("%99s", Etud.datenaiss);
    fflush(stdin);
    
	printf("\nClasses disponibles :\n");
	
    while (fscanf(FClasse, "%d,%99[^\n]\n", &Classe.code, Classe.nom) == 2)
    {
        printf("Code : %d, Nom : %s\n", Classe.code, Classe.nom);
    }
    
	printf("\n Entrer le code de la classe du nouveau etudiant : ");
    scanf("%d", &Etud.CodeClasse);
	fflush(stdin);
	
    fprintf(F, "%d;%s;%s;%s;%s;%d\n", Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, Etud.CodeClasse);
    fclose(F);
}
//----Rechercher et affichage ----//
void Recherche()
{
    int NumR;
    printf("Entrer le numero d'etudiant a rechercher \n");
    scanf("%d", &NumR);
    FILE *F;
    F = fopen("Etudiant.txt", "r");

    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    int found = 0; // Flag to check if the student is found

    while (fscanf(F, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6)
    {
        if (NumR == Etud.Num)
        {
            found = 1;
            printf("-------Information sur l'Etudiant-------\n \n");
            printf("Numero \t:%d\n", Etud.Num);
            printf("Nom \t: %s \n", Etud.Nom);
            printf("Prenom \t : %s \n", Etud.Prenom);
            printf("Email\t: %s \n", Etud.email);
            printf("Date de naissance\t: %s \n", Etud.datenaiss);
            printf("Code de la classe: %d\n", Etud.CodeClasse);
            break; // No need to continue searching once the student is found
        }
    }

    fclose(F);

    if (!found)
    {
        printf("Etudiant non trouv�.\n");
    }
}
//--------Suppression d'etudiants------//
void supprimerEtudiant()
{
    char rep;
    struct Etudiant Etud;
    int NumRech;
    printf("Entrer le numero de l'etudiant a supprimer : ");
    scanf("%d", &NumRech);
    fflush(stdin);

    if (rech(NumRech) == 1)
    {
        printf("\nVoulez-vous vraiment supprimer l'etudiant ? (O/N): ");
        scanf(" %c", &rep);
        fflush(stdin);

        if (rep == 'o' || rep == 'O')
        {
            FILE *F, *Fich;
            F = fopen("Etudiant.txt", "r");
            Fich = fopen("TempEtudiant.txt", "w");

            if (F == NULL || Fich == NULL)
            {
                printf("Erreur lors de l'ouverture des fichiers.\n");
                return;
            }

            while (fscanf(F, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6)
            {
                if (NumRech != Etud.Num)
                {
                    fprintf(Fich, "%d;%s;%s;%s;%s;%d\n", Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, Etud.CodeClasse);
                }
            }

            fclose(Fich);
            fclose(F);
            remove("Etudiant.txt");
            rename("TempEtudiant.txt", "Etudiant.txt");
            printf("Suppression effectuee avec succes.\n");
        }
        else
        {
            printf("\nSuppression annulee.\n");
        }
    }
    else
    {
        printf("\nEtudiant non trouve. Suppression annulee.\n");
    }
}

//--------Afficher la liste des etudiants--------
void AfficherTt()
{
    FILE *F;
    F = fopen("Etudiant.txt", "r");

    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    printf("\n La liste des etudiants est :\n");
    printf("\n Numero \t Nom \t Prenom \t Email \t Date de naissance \t Code de la Classe \n");
    printf("\n");

    while (fscanf(F, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6)
    {
        printf("%d \t", Etud.Num);
        printf("%s \t", Etud.Nom);
        printf("%s \t", Etud.Prenom);
        printf("%s \t", Etud.email);
        printf("%s \t", Etud.datenaiss);
        printf("%d \n", Etud.CodeClasse);
    }

    fclose(F);
}


void gestionEtudiant()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    AJOUTER UN ETUDIANT \n");
    printf("\t\t\t\t\t\t [2]:    MODIFIER UN ETUDIANT \n");
    printf("\t\t\t\t\t\t [3]:    RECHERCHER UN ETUDIANT \n");
    printf("\t\t\t\t\t\t [4]:    SUPPRIMER UN ETUDIANT \n");
    printf("\t\t\t\t\t\t [5]:    AFFICHER LES ETUDIANTS \n");
    printf("\t\t\t\t\t\t [6]:    AFFICHER LES ETUDIANTS PAR CLASSE \n");
    printf("\t\t\t\t\t\t [7]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");

}


//----fonction de modification----//
void modifierEtudiant()
{
    int NumModif;
    printf("Entrer le numero d'etudiant a modifier : ");
    scanf("%d", &NumModif);
    fflush(stdin);

    if (rech(NumModif) == 1)
    {
        FILE *Fich, *F;
        F = fopen("Etudiant.txt", "r");
        Fich = fopen("TempEtudiant.txt", "w");

        if (F == NULL || Fich == NULL)
        {
            printf("Erreur lors de l'ouverture des fichiers.\n");
            return;
        }

        while (fscanf(F, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6)
        {
            if (NumModif == Etud.Num)
            {
                printf("------- Modification des informations de l'Etudiant -------\n \n");
                printf("Nouveau Nom : ");
                scanf("%99s", Etud.Nom);
                fflush(stdin);
                printf("Nouveau Prenom : ");
                scanf("%99s", Etud.Prenom);
                fflush(stdin);
                printf("Nouvel email : ");
                scanf("%99s", Etud.email);
                fflush(stdin);
                printf("Nouvelle date de naissance : ");
                scanf("%99s", Etud.datenaiss);
                fflush(stdin);
                printf("Nouveau code de la classe : ");
                scanf("%d", &Etud.CodeClasse);
                fflush(stdin);

                fprintf(Fich, "%d;%s;%s;%s;%s;%d\n", Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, Etud.CodeClasse);
                printf("Modification effectuee avec succes.\n");
            }
            else
            {
                fprintf(Fich, "%d;%s;%s;%s;%s;%d\n", Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, Etud.CodeClasse);
            }
        }

        fclose(F);
        fclose(Fich);
        remove("Etudiant.txt");
        rename("TempEtudiant.txt", "Etudiant.txt");
    }
    else
    {
        printf("Etudiant non trouv�. Modification annul�e.\n");
    }
}

//-----------------Fonction qui afficher les etudiants d'une classe-----------------------//
void afficherEtudiantsClasse(int codeClasse) {
    FILE *Fetudiant;
    struct Etudiant Etud;

    Fetudiant = fopen("Etudiant.txt", "r");

    if (Fetudiant == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    int etudiantTrouve = 0;

    while (fscanf(Fetudiant,"%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6) {
        

        if (codeClasse == Etud.CodeClasse) {
            etudiantTrouve = 1;
            printf("------- Information sur l'�tudiant -------\n");
            printf("Num�ro : %d\n", Etud.Num);
            printf("Nom : %s\n", Etud.Nom);
            printf("Pr�nom : %s\n", Etud.Prenom);
            printf("Email : %s\n", Etud.email);
            printf("Date de naissance : %s\n", Etud.datenaiss);
            printf("Code de la classe : %d\n", Etud.CodeClasse);
            printf("------------------------------------------\n");
        }
    }

    fclose(Fetudiant);

    if (!etudiantTrouve) {
        printf("Aucun �tudiant trouv� dans la classe %d.\n", codeClasse);
    }
}
