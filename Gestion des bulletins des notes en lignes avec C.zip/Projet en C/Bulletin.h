void gestionBulletin();
void genererBulletins();
void afficherBulletins();
void GenererBulletinIndividuel(int numeroEtudiant);
void supprimerBulletin(int numeroEtudiant);
float calculerMoyenneEtudiant(int numeroEtudiant);
void calculerMoyenneClasse(int codeClasse);
void afficherBulletinsValides(int noteSeuil);

