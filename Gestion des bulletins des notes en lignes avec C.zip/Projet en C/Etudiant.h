#ifndef ETUDIANT_H
#define ETUDIANT_H

void ajouterEtudiant();
void Recherche();
void supprimerEtudiant();
void AfficherTt();
void gestionEtudiant();
void modifierEtudiant();
void afficherEtudiantsClasse(int codeClasse);

struct Etudiant
{
	int Num ;
	char Nom[100];
	char Prenom[100];
	char email[100];
	char datenaiss[100];
	int CodeClasse;
	
};

int rech(int numrech);

#endif // ETUDIANT_H
