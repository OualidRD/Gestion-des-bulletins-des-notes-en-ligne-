#include<stdio.h>

enum niveau {DEUST,licence,master,cycle};

struct classe
{
    int code ;
    char nom[100];
    enum niveau niveau;
};

//--------------Fonction recherche----------//
int rechClasse(int codeRech)
{
    FILE *F;
    struct classe Mat;

    F = fopen("classe.txt", "a+");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 0;
    }

    while (fscanf(F, "%d,%99[^,],%d\n", &Mat.code, Mat.nom, &Mat.niveau) == 3)
    {
        if (Mat.code == codeRech)
        {
            fclose(F);
            return 1; // La classe existe
        }
    }

    fclose(F);
    return 0; // La classe n'existe pas
}



//-------Ajouter Classe -----------//


void ajouterClasse()
{
    struct classe Mat;
    FILE *F;
    int num;

    F = fopen("classe.txt", "a+");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    printf("\n Entrer le code de la classe :");
    scanf("%d", &num);
    
    while (rechClasse(num) == 1)
    {
        printf("\n La classe existe deja : ");
        printf("\n Entrez un autre code : ");
        scanf("%d", &num);
    }

    Mat.code = num;

    printf("\n Entrer le nom de la classe : ");
    scanf(" %99[^\n]", Mat.nom);
    fflush(stdin);

    printf("\n Entrer le niveau (DEUST: 0, Licence: 1, Master: 2, Cycle: 3) : ");
    scanf("%d", &Mat.niveau);
    fflush(stdin);

    fprintf(F, "%d,%s,%d\n", Mat.code, Mat.nom, Mat.niveau);
    fclose(F);

    printf("Ajout de la classe effectue avec succes.\n");
}
//-----------Suppresion classe ----------
void supprimerClasse()
{
    char rep;
    struct classe Mat;
    int NumRech;
    printf("Entrer le code de la classe a supprimer : ");
    scanf("%d", &NumRech);
    fflush(stdin);

    if (rechClasse(NumRech) == 1)
    {
        printf("\nVoulez-vous vraiment supprimer la classe ? (O/N): ");
        scanf(" %c", &rep);
        fflush(stdin);

        if (rep == 'o' || rep == 'O')
        {
            FILE *F, *Fich;
            F = fopen("classe.txt", "r");
            Fich = fopen("TempClasse.txt", "w");

            if (F == NULL || Fich == NULL)
            {
                printf("Erreur lors de l'ouverture des fichiers.\n");
                return;
            }

            while (fscanf(F, "%d,%99[^,],%d\n", &Mat.code, Mat.nom, &Mat.niveau) == 3)
            {
                if (NumRech != Mat.code)
                {
                    fprintf(Fich, "%d,%s,%d\n", Mat.code, Mat.nom, Mat.niveau);
                }
            }

            fclose(Fich);
            fclose(F);
            remove("classe.txt");
            rename("TempClasse.txt", "classe.txt");
            printf("Suppression effectuee avec succes.\n");
        }
        else
        {
            printf("\nSuppression annulee.\n");
        }
    }
    else
    {
        printf("\nLa classe n'existe pas.\n");
    }
}

//------gestion classe---------//
void gestionClasses()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    Ajouter une Classe \n");
    printf("\t\t\t\t\t\t [2]:    Supprimer une Classe \n");
    printf("\t\t\t\t\t\t [3]:    Afficher une classe \n");
    printf("\t\t\t\t\t\t [4]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");
}

void gestionClasses1()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    LICENSE \n");
    printf("\t\t\t\t\t\t [2]:    MASTER \n");
    printf("\t\t\t\t\t\t [3]:    CYCLE \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");
}
//----------Afficher Classe-------------//
void afficherClasse()
{
    FILE *F;
    struct classe Mat;

    F = fopen("classe.txt", "r");
    if (F == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return;
    }

    while (fscanf(F, "%d,%99[^,],%d\n", &Mat.code, Mat.nom, &Mat.niveau) == 3)
    {
        printf("------- Informations sur la Classe -------\n");
        printf("Code : %d\n", Mat.code);
        printf("Nom : %s\n", Mat.nom);
        printf("Niveau : ");

        switch (Mat.niveau)
        {
        case DEUST:
            printf("DEUST\n");
            break;
        case licence:
            printf("Licence\n");
            break;
        case master:
            printf("Master\n");
            break;
        case cycle:
            printf("Cycle\n");
            break;
        default:
            printf("Niveau inconnu\n");
        }

        printf("------------------------------------------\n");
    }

    fclose(F);
}


