#include<stdio.h>
#include<stdlib.h>
#include"Etudiant.h"
#include"Matiere.h"
#include"Classe.h"
#include"Note.h"
#include "Bulletin.h"

//-------Accueil-----//
void accueil()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    GERER ETUDIANTS \n");
    printf("\t\t\t\t\t\t [2]:    GERER LES MATIERES \n");
    printf("\t\t\t\t\t\t [3]:    GERER LES CLASSES \n");
    printf("\t\t\t\t\t\t [4]:    GERER LES NOTES \n");
    printf("\t\t\t\t\t\t [5]:    GERER LES BULLETINS \n");
    printf("\t\t\t\t\t\t [6]:    QUITTER \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");

}

int main()
{	float moy;
    int choix;
    char rep;

    do
    {
        system("cls");
        accueil();
        scanf("%d", &choix);

        switch (choix)
        {
        case 1:
            gestionEtudiant();
            scanf("%d", &choix);
            switch (choix)
            {
            case 1:
                ajouterEtudiant();
                break;
            case 2:
                modifierEtudiant();
                break;
            case 3:
                Recherche();
                break;
            case 4:
                supprimerEtudiant();
                break;
            case 5:
                AfficherTt();
                break;
            case 6:
                printf("Entrer le code de la classe :\n");
                scanf("%d", &choix);
                if(rechClasse(choix)==1){
                afficherEtudiantsClasse(choix);
                }else{
                printf("classe introuvable\n");
            	}
                break;
            default:
                printf("Choix invalide.\n");
            }
            break;

        case 2:
            gestionMatier();
            scanf("%d", &choix);
            switch (choix)
            {
            case 1:
                gestionMatier1();
                ajouterMatiere();
                break;
            case 2:
                supprimerMatiere();
                break;
            case 3:
                afficherMatieres();
                break;
            default:
                printf("Choix invalide.\n");
            }
            break;

        case 3:
            gestionClasses();
            scanf("%d", &choix);
            switch (choix)
            {
            case 1:
                gestionClasses1();
                ajouterClasse();
                break;
            case 2:
                supprimerClasse();
                break;
            case 3:
                afficherClasse();
                break;
            default:
                printf("Choix invalide.\n");
            }
        break;

        case 4:
        	gestionNotes();
            scanf("%d", &choix);
            switch (choix)
            {
            case 1:
            	genererNotes();
            break;
            case 2:
            	afficherNotes();
            break;
			case 3:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                rech(choix);
            	afficherNotesEtudiant(choix);
            break;
            case 4:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                rech(choix);
            	supprimerNotesParEtudiant(choix);
            break;
            case 5:
            	genereruneSeulnote();
            break;
            case 6:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                GenererNoteEtudiant(choix);
            break;
            default:
                printf("Choix invalide.\n");
            }
        break;
    	case 5:
        	gestionBulletin();
            scanf("%d", &choix);
            switch (choix)
            {
            case 1:
            	genererBulletins();
            break;
            case 2:
            	afficherBulletins();
            break;
            case 3:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                rech(choix);
                GenererBulletinIndividuel(choix);
            break;
            case 4:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                rech(choix);
                supprimerBulletin(choix);
            break;
            case 5:
            	printf("Entrer le numero de l'etudiant :\n");
                scanf("%d", &choix);
                rech(choix);
				moy = calculerMoyenneEtudiant(choix);
                printf("La moyenne = %.2f ",moy);
            break;
            case 6:
            	printf("Entrer le code de la classe :\n");
                scanf("%d", &choix);
                rechClasse(choix);
				calculerMoyenneClasse(choix);
            break;
            case 7:
            	printf("Entrer la note seuil :\n");
                scanf("%d", &choix);
				afficherBulletinsValides(choix);
            break;
            default:
                printf("Choix invalide.\n");
        	}
        break;
        case 6:
        	printf("quitter le programme :\n");
        	return;
        break;

        default:
            printf("Choix invalide.\n");
        }

        printf("\nVoulez-vous effectuer une autre action ? (O/N) : ");
        scanf(" %c", &rep);

    } while (rep == 'O' || rep == 'o');

    return 0;
}
