#include<stdio.h>
#include "Etudiant.h"
#include "Matiere.h"
#include <string.h>
#include "Classe.h"

struct Note
{
    int numero;
    char matiere[100] ;
    char niveau[100];
    int note;
};



//------gestion note---------//
void gestionNotes()
{
    printf("\n \t\t\t\t ************************************************\n");
    printf("\n \t\t\t\t\t\t bienvenue \n");
    printf("\n \t\t\t\t ************************************************\n");
    printf("\t\t\t\t\t\t [1]:    Generer les notes \n");
    printf("\t\t\t\t\t\t [2]:    Afficher les notes\n");
    printf("\t\t\t\t\t\t [3]:    Afficher les notes d'un etudiant\n");
    printf("\t\t\t\t\t\t [4]:    Supprimer les notes par etudiant\n");
    printf("\t\t\t\t\t\t [5]:    Generer une note d'une matiere' \n");
    printf("\t\t\t\t\t\t [6]:    Generer une note d'une matiere d'un etudiant' \n");
    printf("\t\t\t\t\t\t [7]:    RETOUR \n");
    printf("\t\t\t\t\t\t VOTRE REPONSE ??: ");
}
//------------Fonction generer note--------------//
void genererNotes()
{
    FILE *Fetudiant, *Fmatiere, *Fnote;
    struct Etudiant Etud;
    struct Matiere Mat;
    struct Note Note;
    char i[100]; // Correction du type de la variable i

    Fetudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "w");

    if (Fetudiant == NULL || Fmatiere == NULL || Fnote == NULL)
    {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    while (fscanf(Fetudiant, "%d;%99[^;];%99[^;];%99[^;];%99[^\n]\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss) == 5)
    {
        fseek(Fmatiere, 0, SEEK_SET);

        printf("Notes pour l'etudiant %d (%s %s) :\n", Etud.Num, Etud.Prenom, Etud.Nom);
        gestionClasses1();
        printf("entrer le Niveau de l'etudiant : ");
        scanf("%s", i);

        while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
        {
            printf("Saisir la note pour la matiere %s : ", Mat.libelle);
            scanf("%d", &Note.note);

            if (rechMat(Mat.references) && rech(Etud.Num))
            {
                Note.numero = Etud.Num;
                strcpy(Note.matiere, Mat.libelle);
                strcpy(Note.niveau, i);

                fprintf(Fnote, "%d;%s;%s;%d\n", Note.numero, Note.matiere, Note.niveau, Note.note);
            }
            else
            {
                printf("Erreur : La matiere ou l'etudiant n'existe pas.\n");
            }
        }

        printf("\n");
    }

    fclose(Fetudiant);
    fclose(Fmatiere);
    fclose(Fnote);
}

//-------------------Afficher les notes--------------------//
void afficherNotes()
{
    FILE *Fnote;
    struct Note Note;

    Fnote = fopen("Note.txt", "r");

    if (Fnote == NULL)
    {
        printf("Erreur lors de l'ouverture du fichier Note.txt.\n");
        return;
    }

    printf("\n-----------------------------------------\n");
    printf("  Affichage des Notes\n");
    printf("-----------------------------------------\n");

    while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &Note.numero, Note.matiere, Note.niveau, &Note.note) == 4)
    {
        printf("Numero Etudiant : %d\n", Note.numero);
        printf("Matiere : %s\n", Note.matiere);
        printf("Niveau : %s\n", Note.niveau);
        printf("Note : %d\n", Note.note);
        printf("-----------------------------------------\n");
    }

    fclose(Fnote);
}

//-------------Fonction Afficher les notes d'un etudiant-----------------//
void afficherNotesEtudiant(int numeroEtudiant) {
    FILE *Fnote;
    struct Note Note;

    Fnote = fopen("Note.txt", "r");

    if (Fnote == NULL) {
        printf("Erreur lors de l'ouverture du fichier Note.txt.\n");
        return;
    }

    printf("\n-----------------------------------------\n");
    printf("  Affichage des Notes de l'�tudiant %d\n", numeroEtudiant);
    printf("-----------------------------------------\n");

    int notesTrouvees = 0;

    while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &Note.numero, Note.matiere, Note.niveau, &Note.note) == 4) {
        if (Note.numero == numeroEtudiant) {
            printf("Matiere : %s\n", Note.matiere);
            printf("Niveau : %s\n", Note.niveau);
            printf("Note : %d\n", Note.note);
            printf("-----------------------------------------\n");
            notesTrouvees = 1;
        }
    }

    fclose(Fnote);

    if (!notesTrouvees) {
        printf("Aucune note trouv�e pour l'�tudiant %d.\n", numeroEtudiant);
    }
}


//--------------Fonction supprimer note---------------------//
void supprimerNotesParEtudiant(int numeroEtudiant)
{
    FILE *Fnote, *Ftemp;
    struct Note Note;

    Fnote = fopen("Note.txt", "r");
    Ftemp = fopen("TempNote.txt", "w");

    if (Fnote == NULL || Ftemp == NULL)
    {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    while (fscanf(Fnote, "%d;%99[^;];%99[^;];%d\n", &Note.numero, Note.matiere, Note.niveau, &Note.note) == 4)
    {
        if (Note.numero != numeroEtudiant)
        {
            fprintf(Ftemp, "%d;%s;%s;%d\n", Note.numero, Note.matiere, Note.niveau, Note.note);
        }
    }

    fclose(Fnote);
    fclose(Ftemp);

    remove("Note.txt");
    rename("TempNote.txt", "Note.txt");

    printf("Suppression des notes de l'etudiant %d effectu�e avec succ�s.\n", numeroEtudiant);
}

//------------Fonction generer une seule note d'une matiere choisie--------------
void genereruneSeulnote()
{
    FILE *Fetudiant, *Fmatiere, *Fnote;
    struct Etudiant Etud;
    struct Matiere Mat;
    struct Note Note;
    char i[100]; 

    Fetudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "w");

    if (Fetudiant == NULL || Fmatiere == NULL || Fnote == NULL)
    {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    while (fscanf(Fetudiant, "%d;%99[^;];%99[^;];%99[^;];%99[^\n]\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss) == 5)
    {
        fseek(Fmatiere, 0, SEEK_SET);

        printf("Notes pour l'etudiant %d (%s %s) :\n", Etud.Num, Etud.Prenom, Etud.Nom);
        gestionClasses1();
        printf("entrer le Niveau de l'etudiant : ");
        scanf("%s", i);

        printf("Choisir la matiere pour laquelle vous souhaitez entrer la note :\n");

        while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
        {
            printf("%d. %s\n", Mat.references, Mat.libelle);
        }

        int choixMatiere;
        printf("Entrez le num�ro de la mati�re : ");
        scanf("%d", &choixMatiere);

        // V�rifier si la mati�re choisie existe
        fseek(Fmatiere, 0, SEEK_SET);
        int matiereExist = 0;
        while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3)
        {
            if (Mat.references == choixMatiere)
            {
                matiereExist = 1;
                break;
            }
        }

        if (matiereExist)
        {
            printf("Saisir la note pour la matiere choisie : ");
            scanf("%d", &Note.note);

            Note.numero = Etud.Num;
            strcpy(Note.matiere, Mat.libelle);
            strcpy(Note.niveau, i);

            fprintf(Fnote, "%d;%s;%s;%d\n", Note.numero, Note.matiere, Note.niveau, Note.note);
        }
        else
        {
            printf("Erreur : La matiere choisie n'existe pas.\n");
        }

        printf("\n");
    }

    fclose(Fetudiant);
    fclose(Fmatiere);
    fclose(Fnote);
}


//-------------------------------Fonction generer une seule note d'une matiere choisie d'un etudiant choisi--------------------//
void GenererNoteEtudiant(int numEtud) {
    FILE *Fmatiere, *Fnote, *Fetudiant;
    struct Matiere Mat;
    struct Note Note;
    struct Etudiant Etud;
    char niveau[100];

    Fetudiant = fopen("Etudiant.txt", "r");
    Fmatiere = fopen("Matiere.txt", "r");
    Fnote = fopen("Note.txt", "a"); // Utilisation du mode "a" pour ajouter au fichier existant

    if (Fetudiant == NULL || Fmatiere == NULL || Fnote == NULL) {
        printf("Erreur lors de l'ouverture des fichiers.\n");
        return;
    }

    // Recherche de l'�tudiant par son num�ro
    int etudiantTrouve = 0;
    while (fscanf(Fetudiant, "%d;%99[^;];%99[^;];%99[^;];%99[^;];%d\n", &Etud.Num, Etud.Nom, Etud.Prenom, Etud.email, Etud.datenaiss, &Etud.CodeClasse) == 6) {
        if (Etud.Num == numEtud) {
            etudiantTrouve = 1;
            break;
        }
    }

    if (!etudiantTrouve) {
        printf("�tudiant non trouv�.\n");
        fclose(Fetudiant);
        fclose(Fmatiere);
        fclose(Fnote);
        return;
    }

    printf("------- Informations sur l'�tudiant -------\n");
    printf("Num�ro : %d\n", Etud.Num);
    printf("Nom : %s\n", Etud.Nom);
    printf("Pr�nom : %s\n", Etud.Prenom);
    printf("Email : %s\n", Etud.email);
    printf("Date de naissance : %s\n", Etud.datenaiss);
    printf("Code de la classe : %d\n", Etud.CodeClasse);
    printf("------------------------------------------\n");

    printf("Choisissez la matiere pour laquelle vous souhaitez entrer la note :\n");

    while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3) {
        printf("%d. %s\n", Mat.references, Mat.libelle);
    }

    int choixMatiere;
    printf("Entrez le num�ro de la mati�re : ");
    scanf("%d", &choixMatiere);

    // V�rifier si la mati�re choisie existe
    fseek(Fmatiere, 0, SEEK_SET);
    int matiereExist = 0;
    while (fscanf(Fmatiere, "%d,%99[^,],%d\n", &Mat.references, Mat.libelle, &Mat.coefficient) == 3) {
        if (Mat.references == choixMatiere) {
            matiereExist = 1;
            break;
        }
    }

    if (matiereExist) {
        printf("Saisir la note pour la matiere choisie : ");
        scanf("%d", &Note.note);

        Note.numero = numEtud;
        strcpy(Note.matiere, Mat.libelle);
        // Stoker le code de la classe dans Note.niveau
        sprintf(Note.niveau, "%d", Etud.CodeClasse);

        fprintf(Fnote, "%d;%s;%s;%d\n", Note.numero, Note.matiere, Note.niveau, Note.note);
        printf("Note g�n�r�e avec succ�s pour l'�tudiant num�ro %d.\n", numEtud);
    } else {
        printf("Erreur : La matiere choisie n'existe pas.\n");
    }

    fclose(Fetudiant);
    fclose(Fmatiere);
    fclose(Fnote);
}

