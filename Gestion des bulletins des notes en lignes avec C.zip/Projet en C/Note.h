#ifndef NOTE_H
#define NOTE_H

void genererNotes();
void afficherNotes();
void afficherNotesEtudiant(int numeroEtudiant);
void gestionNotes();
void supprimerNotesParEtudiant(int numeroEtudiant);
void genereruneSeulnote();
void GenererNoteEtudiant(int numEtud);
struct Note
{
    int numero;
    char matiere[100] ;
    char niveau[100];
    int note;
};

#endif //NOTE_H
